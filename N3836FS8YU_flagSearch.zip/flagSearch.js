let searchInputE1 = document.getElementById('searchInput');
let resultCountriesE1 = document.getElementById('resultCountries');
let spinnerE1 = document.getElementById('spinner');
let searchInputVal = "";
let countriesList = [];

function append(i) {
    let {
        name,
        flag,
        population
    } = i;
    //console.log(name);
    // country-card==div
    let countaryCard = document.createElement('div');
    countaryCard.classList.add('country-card', 'col-11', 'col-md-5', "mr-auto", 'ml-auto', 'd-flex', 'flex-row');
    resultCountriesE1.appendChild(countaryCard);
    // img ==country-flag
    let imgE1 = document.createElement('img');
    imgE1.src = flag;
    imgE1.classList.add('country-flag', 'mt-auto', 'mb-auto');
    resultCountriesE1.appendChild(imgE1);
    // div d-flex flex-row
    let infoCard = document.createElement('div');
    infoCard.classList.add('d-flex', 'flex-column', 'ml-4');
    resultCountriesE1.appendChild(infoCard);
    // Name ==country-name
    let title = document.createElement('p');
    title.classList.add('country-name');
    title.textContent = name;
    infoCard.appendChild(title);
    // popoulation == country-population
    let populationE1 = document.createElement('p');
    populationE1.classList.add('country-population');
    populationE1.textContent = population;
    infoCard.appendChild(populationE1);

}

function displaySearchResults() {
    resultCountriesE1.textContent = "";
    for (let country of countriesList) {
        let countryName = country.name;
        console.log(countryName);

        if (countryName.toLowerCase().includes(searchInputVal)) { //Use toLowerCase() method to convert the string to lower case
            append(country);
        }
    }
}

function getCountries() {
    spinnerE1.classList.remove('d-none');
    let search = searchInputE1.value;
    let url = "https://apis.ccbp.in/countries-data";
    let options = {
        method: "GET"
    };
    fetch(url, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            //resultCountriesE1.textContent=json.value;
            spinnerE1.classList.add('d-none');
            countriesList = data;
            //display(data);
            displaySearchResults();
        });
}

function onChange1() {
    searchInputVal = event.target.value;
    displaySearchResults();
}
getCountries();
searchInputE1.addEventListener('keydown', onChange1);