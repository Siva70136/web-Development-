let counterValue = document.getElementById('counterValue');
counterValue.classList.add("counter");
let incrementBtn = document.getElementById('incrementBtn');

let clickCount = counterValue.textContent;
localStorage.setItem("clickCount", clickCount);

function increment() {
    let clickCount = localStorage.getItem('clickCount');
    clickCount = parseInt(clickCount) + 1;
    counterValue.textContent = clickCount;
    localStorage.setItem("clickCount", clickCount);

}

incrementBtn.onclick = function() {
    increment();
}



let titleInput = document.getElementById('titleInput');
let reviewTextarea = document.getElementById('reviewTextarea');
let movieReviewsContainer = document.getElementById('movieReviewsContainer');
let buttonElement = document.getElementById('addBtn');

let container = document.createElement('div');
let containerId = "reviewsContainer";
container.id = containerId;
movieReviewsContainer.appendChild(container);

function addReview() {


    let name = document.createElement('h1');
    name.classList.add('heading');
    let title = titleInput.value;
    if (title === "") {
        alert("Enter a movie name");
        return;
    } else {
        name.textContent = "MOVIE TITLE : " + title;
    }
    container.appendChild(name);

    let review = document.createElement('p');
    review.classList.add('review2');
    review.textContent = "REVIEW : " + reviewTextarea.value;
    container.appendChild(review);
    titleInput.value = "";
    reviewTextarea.value = "";
    console.log(container);
}

buttonElement.onclick = function() {
    addReview();
};