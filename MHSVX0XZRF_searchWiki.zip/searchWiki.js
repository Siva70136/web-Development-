let searchResultsE1 = document.getElementById('searchResults');
let searchInputE1 = document.getElementById('searchInput');
let spinnerE1 = document.getElementById('spinner');

function createAppend(result) {
    let {
        link,
        title,
        description
    } = result;
    console.log(link);

    //create div == result-item
    let resultItem = document.createElement('div');
    resultItem.classList.add('result-item');
    searchResultsE1.appendChild(resultItem);
    //create a  == result-title
    let resultTitle = document.createElement('a');
    resultTitle.classList.add('result-title');
    resultTitle.href = link;
    resultTitle.textContent = title;
    resultTitle.target = "_blank";
    resultItem.appendChild(resultTitle);
    // br
    let break1 = document.createElement('br');
    resultItem.appendChild(break1);
    //create link == result-url
    let urlItem = document.createElement('a');
    urlItem.href = link;
    urlItem.classList.add('result-url');
    urlItem.textContent = link;
    urlItem.target = "_blank";
    resultItem.appendChild(urlItem);
    //br
    let break2 = document.createElement('br');
    resultItem.appendChild(break2);
    //create des == link-description
    let descriptionE1 = document.createElement('p');
    descriptionE1.textContent = description;
    descriptionE1.classList.add('link-description');
    resultItem.appendChild(descriptionE1);
}

function displayResults(search_result) {
    spinnerE1.classList.add('d-none');
    for (let result of search_result) {
        createAppend(result);
    }
}

function searchWiki(event) {
    if (event.key === "Enter") {
        spinnerE1.classList.remove("d-none");
        let searchValue = searchInputE1.value;
        let url = "https://apis.ccbp.in/wiki-search?search=" + searchValue;
        let options = {
            method: "GET"
        };
        fetch(url, options)
            .then(function(response) {
                return response.json();
            })
            .then(function(data) {
                searchResultsE1.textContent = "";
                let {
                    search_results
                } = data;
                displayResults(search_results);
            });

    }

}
searchInputE1.addEventListener('keydown', searchWiki);